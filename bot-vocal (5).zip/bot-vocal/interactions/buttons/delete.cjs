const { deleteVoiceChannel } = require("../../utils/deleteVoiceChannel.cjs");

module.exports = async (interaction) => {
  const channel = interaction.member.voice.channel;

  if (!channel) {
    return interaction.reply({
      content: "❌ Tu n'es pas dans un salon vocal.",
      ephemeral: true,
    });
  }

  try {
    // On répond AVANT de tout supprimer
    await interaction.reply({
      content: "🗑️ Suppression en cours...",
      ephemeral: true,
    });

    // Supprimer les salons
    await deleteVoiceChannel(channel, interaction.client);

    // ✅ Pas besoin de editReply ici
    // Le message va disparaître avec le salon

  } catch (err) {
    console.error("Erreur delete.cjs :", err);
    try {
      await interaction.followUp({
        content: "❌ Une erreur est survenue pendant la suppression.",
        ephemeral: true,
      });
    } catch {}
  }
};
