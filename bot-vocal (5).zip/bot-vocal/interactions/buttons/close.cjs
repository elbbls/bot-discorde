module.exports = async (interaction) => {
  const channel = interaction.member.voice.channel;

  if (!channel) {
    return interaction.reply({
      content: "❌ Tu n'es pas dans un salon vocal.",
      ephemeral: true,
    });
  }

  try {
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
      Connect: false,
    });

    await interaction.reply({
      content: "🔒 Salon fermé aux nouveaux arrivants.",
      ephemeral: true,
    });
  } catch (err) {
    console.error("Erreur bouton close :", err);
    await interaction.reply({
      content: "❌ Impossible de fermer le salon.",
      ephemeral: true,
    });
  }
};
