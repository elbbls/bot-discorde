module.exports = async (interaction) => {
  const channel = interaction.member.voice.channel;

  if (!channel) {
    return interaction.reply({
      content: "❌ Tu n'es pas dans un salon vocal.",
      ephemeral: true,
    });
  }

  try {
    await channel.permissionOverwrites.edit(channel.guild.roles.everyone, {
      Connect: true,
    });

    await interaction.reply({
      content: "🔓 Salon ouvert à tous.",
      ephemeral: true,
    });
  } catch (err) {
    console.error("Erreur bouton open :", err);
    await interaction.reply({
      content: "❌ Impossible d’ouvrir le salon.",
      ephemeral: true,
    });
  }
};
