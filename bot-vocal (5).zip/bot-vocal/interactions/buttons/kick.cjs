const {
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
} = require("discord.js");

module.exports = async (interaction) => {
  const member = interaction.member;
  const voiceChannel = member.voice.channel;

  if (!voiceChannel) {
    return interaction.reply({
      content: "❌ Tu dois être dans un salon vocal.",
      ephemeral: true,
    });
  }

  // Récupère tous les membres dans la vocale SAUF l'utilisateur lui-même
  const otherMembers = voiceChannel.members.filter(m => m.id !== member.id);

  if (otherMembers.size === 0) {
    return interaction.reply({
      content: "👤 Tu es seul dans le salon, personne à exclure.",
      ephemeral: true,
    });
  }

  // Crée les options du menu déroulant
  const options = otherMembers.map((m) =>
    new StringSelectMenuOptionBuilder()
      .setLabel(m.user.username)
      .setDescription(`Expulser ${m.user.username}`)
      .setValue(m.id)
  );

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("kick_select")
    .setPlaceholder("Choisis qui kick")
    .addOptions(options);

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await interaction.reply({
    content: "🔴 Sélectionne un membre à expulser de ta vocale :",
    components: [row],
    ephemeral: true,
  });
};
