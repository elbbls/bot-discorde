const { ActionRowBuilder, StringSelectMenuBuilder, ComponentType, PermissionFlagsBits } = require("discord.js");

module.exports = async (interaction) => {
  const voiceChannel = interaction.member.voice.channel;

  if (!voiceChannel) {
    return interaction.reply({
      content: "❌ Tu dois être dans ta vocale pour utiliser ce bouton.",
      ephemeral: true,
    });
  }

  // Vérifie que l'utilisateur est le propriétaire de la vocale
  const perms = voiceChannel.permissionOverwrites.cache.get(interaction.user.id);
  if (!perms || !perms.allow.has(PermissionFlagsBits.Connect)) {
    return interaction.reply({
      content: "❌ Tu n'es pas le propriétaire de cette vocale.",
      ephemeral: true,
    });
  }

  // Filtrer les membres qui ont été autorisés manuellement
  const allowedMembers = voiceChannel.permissionOverwrites.cache.filter(
    (overwrite) =>
      overwrite.allow.has("Connect") &&
      overwrite.type === 1 && // 1 = utilisateur
      overwrite.id !== interaction.user.id // exclut le propriétaire
  );

  if (allowedMembers.size === 0) {
    return interaction.reply({
      content: "❌ Aucun membre à retirer.",
      ephemeral: true,
    });
  }

  const options = allowedMembers.map((overwrite) => {
    const member = interaction.guild.members.cache.get(overwrite.id);
    return {
      label: member?.user?.username || "Utilisateur inconnu",
      value: overwrite.id,
    };
  });

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("remove_select")
    .setPlaceholder("🔵 Choisis un membre à retirer")
    .addOptions(options.slice(0, 25)); // max 25 options

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await interaction.reply({
    content: "👥 Sélectionne un membre à retirer de ta vocale :",
    components: [row],
    ephemeral: true,
  });
};
