module.exports = async (interaction) => {
  try {
    const member = interaction.member;
    const voiceChannel = member.voice.channel;

    // Vérifie si l’utilisateur est bien dans une vocale
    if (!voiceChannel) {
      await interaction.reply({
        content: "⚠️ Tu dois être dans un salon vocal pour signaler.",
        ephemeral: true,
      });
      return;
    }

    const guild = interaction.guild;
    const modChannel = guild.channels.cache.find(ch => ch.name === "mod-bot" && ch.isTextBased());

    if (!modChannel) {
      await interaction.reply({
        content: "❌ Impossible de trouver le salon #mod-bot pour envoyer l’alerte.",
        ephemeral: true,
      });
      return;
    }

    // Envoie l'alerte dans #mod-bot
    await modChannel.send({
      content: `🚨 **ALERTE**\n<@${member.id}> a signalé un problème dans le salon vocal <#${voiceChannel.id}>.\n<@&1377371849352155348>`,
    });

    // Répond à l’utilisateur
    await interaction.reply({
      content: "✅ Ton signalement a été envoyé aux modérateurs.",
      ephemeral: true,
    });

  } catch (error) {
    console.error("❌ Erreur dans le bouton report :", error);
    if (!interaction.replied) {
      await interaction.reply({
        content: "❌ Erreur lors de l’envoi du signalement.",
        ephemeral: true,
      });
    }
  }
};
