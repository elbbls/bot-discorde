const { ActionRowBuilder, StringSelectMenuBuilder, ComponentType, PermissionFlagsBits } = require("discord.js");

module.exports = async (interaction) => {
  const voiceChannel = interaction.member.voice.channel;

  if (!voiceChannel) {
    return interaction.reply({
      content: "❌ Tu dois être dans ta vocale pour utiliser ce bouton.",
      ephemeral: true,
    });
  }

  // Vérifie que l'utilisateur est le propriétaire de la vocale (a les perms de connection)
  const perms = voiceChannel.permissionOverwrites.cache.get(interaction.user.id);
  if (!perms || !perms.allow.has(PermissionFlagsBits.Connect)) {
    return interaction.reply({
      content: "❌ Tu n'es pas le propriétaire de cette vocale.",
      ephemeral: true,
    });
  }

  // Liste des membres dans le serveur, sauf l'utilisateur actuel
  const members = interaction.guild.members.cache.filter(
    (m) => !m.user.bot && m.id !== interaction.user.id
  );

  if (members.size === 0) {
    return interaction.reply({
      content: "❌ Aucun membre à ajouter.",
      ephemeral: true,
    });
  }

  const options = members.map((member) => ({
    label: member.user.username,
    value: member.id,
  })).slice(0, 25); // Discord limite à 25 options max

  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId("add_select")
    .setPlaceholder("➕ Choisis un membre à autoriser")
    .addOptions(options);

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await interaction.reply({
    content: "👥 Sélectionne un membre à ajouter à ta vocale :",
    components: [row],
    ephemeral: true,
  });
};
