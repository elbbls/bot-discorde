module.exports = async (interaction) => {
  const selectedUserId = interaction.values[0];
  const guild = interaction.guild;
  const memberToKick = guild.members.cache.get(selectedUserId);

  const author = interaction.member;
  const voiceChannel = author.voice.channel;

  if (!voiceChannel) {
    return interaction.reply({
      content: "❌ Tu n'es plus dans le salon vocal.",
      ephemeral: true,
    });
  }

  if (!memberToKick || memberToKick.voice.channelId !== voiceChannel.id) {
    return interaction.reply({
      content: "⚠️ Ce membre n’est plus dans ta vocale.",
      ephemeral: true,
    });
  }

  try {
    await memberToKick.voice.disconnect();
    await interaction.reply({
      content: `✅ ${memberToKick.user.username} a été expulsé de ta vocale.`,
      ephemeral: true,
    });
  } catch (err) {
    console.error("❌ Erreur kick vocal :", err);
    await interaction.reply({
      content: "❌ Impossible d'expulser ce membre.",
      ephemeral: true,
    });
  }
};
