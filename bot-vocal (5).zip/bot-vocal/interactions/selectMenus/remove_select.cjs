module.exports = async (interaction) => {
  const selectedUserId = interaction.values[0];
  const member = interaction.guild.members.cache.get(selectedUserId);
  const voiceChannel = interaction.member.voice.channel;

  if (!voiceChannel) {
    return interaction.reply({
      content: "❌ Tu dois être dans ta vocale temporaire pour retirer l'accès à quelqu’un.",
      ephemeral: true,
    });
  }

  // Vérifie si l'utilisateur est le créateur de la vocale
  const permissionOverwrites = voiceChannel.permissionOverwrites.cache.get(interaction.user.id);
  if (!permissionOverwrites || !permissionOverwrites.allow.has("Connect")) {
    return interaction.reply({
      content: "❌ Tu n'es pas le propriétaire de cette vocale.",
      ephemeral: true,
    });
  }

  try {
    await voiceChannel.permissionOverwrites.edit(selectedUserId, {
      Connect: false,
      ViewChannel: false,
    });

    await interaction.reply({
      content: `🔵 ${member.user.username} ne peut plus rejoindre ta vocale.`,
      ephemeral: true,
    });
  } catch (err) {
    console.error("Erreur lors du retrait des permissions :", err);
    await interaction.reply({
      content: "❌ Une erreur est survenue lors du retrait des permissions.",
      ephemeral: true,
    });
  }
};
