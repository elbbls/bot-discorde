// utils/generatePanel.cjs
const {
  ButtonBuilder,
  ButtonStyle,
  ActionRowBuilder,
  EmbedBuilder,
} = require('discord.js');

module.exports = async function generatePanel(textChannel, ownerId) {
  const embed = new EmbedBuilder()
    .setTitle('🎛 Panneau de contrôle')
    .setDescription(`Contrôle pour la vocale temporaire de <@${ownerId}>.`);

  const row1 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('open')
      .setLabel('🟢 Ouvrir')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('close')
      .setLabel('🟠 Fermer')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('add')
      .setLabel('➕ Ajouter')
      .setStyle(ButtonStyle.Primary)
  );

  const row2 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('remove')
      .setLabel('➖ Retirer')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('kick')
      .setLabel('❌ Kick')
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId('report')
      .setLabel('❗ Signaler')
      .setStyle(ButtonStyle.Danger)
  );

  const row3 = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('delete')
      .setLabel('🗑 Supprimer')
      .setStyle(ButtonStyle.Danger)
  );

  await textChannel.send({
    content: `Voici le panneau de contrôle pour <@${ownerId}>`,
    embeds: [embed],
    components: [row1, row2, row3],
  });
};
