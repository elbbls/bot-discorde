module.exports.deleteVoiceChannel = async (voiceChannel, client) => {
  try {
    // Cherche le salon texte lié
    const guild = voiceChannel.guild;

    const linkedTextChannel = guild.channels.cache.find(
      (ch) =>
        ch.name === `panel-${voiceChannel.name.replace(/^_/, "")}` &&
        ch.type === 0 // GuildText
    );

    if (linkedTextChannel && linkedTextChannel.deletable) {
      console.log("🗑️ Suppression du salon texte :", linkedTextChannel.name);
      await linkedTextChannel.delete();
    }

    if (voiceChannel.deletable) {
      console.log("🗑️ Suppression du salon vocal :", voiceChannel.name);
      await voiceChannel.delete();
    }

  } catch (error) {
    console.error("Erreur lors de la suppression :", error);
  }
};
