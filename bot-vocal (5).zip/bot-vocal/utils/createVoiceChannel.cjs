const { ChannelType, PermissionFlagsBits } = require("discord.js");
const { modChannelId } = require("../config.json");
const generatePanel = require("./generatePanel.cjs");

module.exports = async (state) => {
  try {
    const guild = state.guild;
    const user = state.member?.user;

    if (!user) {
      console.error("❌ Impossible de récupérer l'utilisateur depuis l'état vocal.");
      return;
    }

    const userName = user.username;

    // Création du salon vocal temporaire
    const voiceChannel = await guild.channels.create({
      name: `🔊 ${userName}`,
      type: ChannelType.GuildVoice,
      parent: state.channel.parent,
      permissionOverwrites: [
        {
          id: guild.roles.everyone,
          allow: [PermissionFlagsBits.Connect],
        },
        {
          id: user.id,
          allow: [PermissionFlagsBits.Connect, PermissionFlagsBits.MuteMembers],
        },
      ],
    });

    // Déplacement de l'utilisateur dans le nouveau salon
    await state.member.voice.setChannel(voiceChannel);

    // Création du salon textuel lié
    const textChannel = await guild.channels.create({
      name: `panel-${user.username.toLowerCase()}`,
      type: ChannelType.GuildText,
      parent: state.channel.parent,
      permissionOverwrites: [
        {
          id: guild.roles.everyone,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
        },
      ],
    });

    // Envoie du panneau de contrôle dans le salon texte
    await generatePanel(textChannel, voiceChannel, user);

    // Sauvegarde l'ID du texte dans la mémoire du salon vocal (optionnel pour liaison)
    voiceChannel.textPanelId = textChannel.id;
  } catch (err) {
    console.error("💥 Erreur createVoiceChannel :", err);
  }
};
