const path = require("path");
const fs = require("fs");

module.exports = async (interaction) => {
  try {
    if (interaction.isButton()) {
      const buttonId = interaction.customId;
      const filePath = path.join(__dirname, "..", "interactions", "buttons", `${buttonId}.cjs`);

      if (fs.existsSync(filePath)) {
        delete require.cache[require.resolve(filePath)];
        const handler = require(filePath);
        if (typeof handler === "function") {
          await handler(interaction);
        } else {
          console.error(`❌ Le fichier ${buttonId}.cjs n'exporte pas une fonction.`);
          await interaction.reply({
            content: "❌ Erreur interne dans le bouton.",
            ephemeral: true,
          });
        }
      } else {
        console.warn(`❓ Bouton inconnu : ${buttonId}`);
        await interaction.reply({
          content: "❓ Bouton inconnu.",
          ephemeral: true,
        });
      }
    }

    else if (interaction.isStringSelectMenu()) {
      const selectId = interaction.customId;
      const filePath = path.join(__dirname, "..", "interactions", "selectMenus", `${selectId}.cjs`);

      if (fs.existsSync(filePath)) {
        delete require.cache[require.resolve(filePath)];
        const handler = require(filePath);
        if (typeof handler === "function") {
          await handler(interaction);
        } else {
          console.error(`❌ Le fichier ${selectId}.cjs n'exporte pas une fonction.`);
          await interaction.reply({
            content: "❌ Erreur interne dans le menu déroulant.",
            ephemeral: true,
          });
        }
      } else {
        console.warn(`❓ Menu déroulant inconnu : ${selectId}`);
        await interaction.reply({
          content: "❓ Menu déroulant inconnu.",
          ephemeral: true,
        });
      }
    }

  } catch (err) {
    console.error("❌ Erreur interactionCreate :", err);
    if (interaction.replied || interaction.deferred) {
      await interaction.followUp({
        content: "❌ Une erreur est survenue.",
        ephemeral: true,
      });
    } else {
      await interaction.reply({
        content: "❌ Une erreur est survenue.",
        ephemeral: true,
      });
    }
  }
};
