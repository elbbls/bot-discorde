const { triggerVoiceChannelName } = require("../config.json");
const createVoiceChannel = require("../utils/createVoiceChannel.cjs");

module.exports = async (oldState, newState) => {
  console.log("🔁 voiceStateUpdate déclenché !");

  try {
    // === ENTRÉE DANS LE SALON DÉCLENCHEUR ===
    if (!oldState.channel && newState.channel) {
      const enteredChannel = newState.channel;
      console.log("👤 Utilisateur est entré dans :", enteredChannel.name);

      if (enteredChannel.name === triggerVoiceChannelName) {
        console.log("🎤 Salon déclencheur détecté ! Création du vocal...");
        await createVoiceChannel(newState);
      }
    }

    // === QUITTE UN SALON VOCAL ===
    if (oldState.channel && oldState.channel.members.size === 0) {
      const voiceChannel = oldState.channel;

      // Vérifie si c’est un salon temporaire (créé par le bot)
      if (voiceChannel.name.startsWith("🔊")) {
        console.log("🧹 Suppression du salon vocal :", voiceChannel.name);

        const guild = voiceChannel.guild;

        // Trouver le salon texte lié
        const linkedText = guild.channels.cache.find((ch) =>
          ch.name.startsWith("panel-") &&
          ch.parentId === voiceChannel.parentId
        );

        // Supprimer le salon texte s’il existe
        if (linkedText && guild.channels.cache.has(linkedText.id)) {
          await linkedText.delete().catch(console.error);
          console.log("🗑️ Salon texte supprimé :", linkedText.name);
        } else {
          console.log("⚠️ Salon texte introuvable ou déjà supprimé");
        }

        // Supprimer le salon vocal s’il existe encore
        if (voiceChannel && guild.channels.cache.has(voiceChannel.id)) {
          await voiceChannel.delete().catch(console.error);
          console.log("🗑️ Salon vocal supprimé :", voiceChannel.name);
        } else {
          console.log("⚠️ Salon vocal déjà supprimé :", voiceChannel?.name);
        }
      }
    }
  } catch (err) {
    console.error("❌ Erreur voiceStateUpdate :", err);
  }
};
