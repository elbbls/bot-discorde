const { Client, GatewayIntentBits, Partials } = require("discord.js");
const { token } = require("./config.json");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
  ],
  partials: [Partials.Channel],
});

client.once("ready", () => {
  console.log(`✅ Bot connecté en tant que ${client.user.tag}`);
});

// === Enregistrement manuel des événements ===
client.on("interactionCreate", require("./events/interactionCreate.cjs"));
client.on("voiceStateUpdate", require("./events/voiceStateUpdate.cjs"));

client.login(token);
